<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wordpress');

/** MySQL database password */
define('DB_PASSWORD', 'secret');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */

define('AUTH_KEY',         'VlP7pvqM-R7GPY{[U>0e=@crnUkd-p@hdB}A:A!B-@7BccuBh.w?N]<4fKHpN}S|');
define('SECURE_AUTH_KEY',  ' DJh-{;G)K3KJEe}ZOxE0S!et={,>c;TWqUST+=bjE`a+cbW|36mVlP`@mm2$Iep');
define('LOGGED_IN_KEY',    'Q8>H!2<E8^ruK!p@wD_/-X30*k,D_@u+uHKlfAz2,S[/{b1T0 ZL7ufg]Vp5t2?!');
define('NONCE_KEY',        'Z&p=fZye,/,EQCe4Wh%T>Gy ?91WSgYplQbZdxD.D@R)_3!6L-scra;aDZT.^+hN');
define('AUTH_SALT',        'MXpOA[IwOu%P+BN1]m^t]#2/X!~h)Ad(Wx[^cc9vntNhVkf(-L#_-l<yB1B_Zs7>');
define('SECURE_AUTH_SALT', 'I=H$I6.Z:wgr6<,<lCLo?;.f*IpkKVwTE7y_$Z%#M|70-L!V;Y0g(;!4XsAw5hWc');
define('LOGGED_IN_SALT',   '|f0jl0}H<N%J](Orn[vcbO|@I|u{~tO-?k)KTD0A+(/GRzZ>lIXUu>c]1ue*XoPa');
define('NONCE_SALT',       '<|ni=4~OwEz a+87-@1kNIU)V(AM|9<+3:ftYT?w8m{G9JuH>SH@?kL-)MBSw?YI');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/** Disable Automatic Updates Completely */
define( 'AUTOMATIC_UPDATER_DISABLED', False );

/** Define AUTOMATIC Updates for Components. */
define( 'WP_AUTO_UPDATE_CORE', True );

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
